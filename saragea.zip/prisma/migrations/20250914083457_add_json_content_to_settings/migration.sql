-- AlterTable
ALTER TABLE "public"."Setting" ADD COLUMN     "jsonContent" JSONB;
