-- AlterTable
ALTER TABLE "public"."Setting" ADD COLUMN     "isEnabled" BOOLEAN NOT NULL DEFAULT true;
