-- AlterTable
ALTER TABLE "public"."PaymentGateway" ADD COLUMN     "meta" JSONB;
