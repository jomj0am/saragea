/*
  Warnings:

  - You are about to drop the column `value` on the `Setting` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "public"."Setting" DROP COLUMN "value";
