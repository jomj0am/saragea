// src/lib/pusher.ts
import PusherServer from "pusher";
import PusherClient from "pusher-js";

// ✅ Logic for Server (API Routes)
export const getPusherServer = () => {
  const appId = process.env.PUSHER_APP_ID;
  const key = process.env.NEXT_PUBLIC_PUSHER_KEY;
  const secret = process.env.PUSHER_SECRET;
  const cluster = process.env.PUSHER_CLUSTER || "ap2";

  if (!appId || !key || !secret) {
    // Return null during build to prevent crashing
    return null;
  }

  return new PusherServer({
    appId,
    key,
    secret,
    cluster,
    useTLS: true,
  });
};

// ✅ Logic for Client (Frontend)
// PusherClient usually doesn't crash the build because it's used inside useEffect,
// but we'll make it safe anyway.
export const getPusherClient = () => {
  const key = process.env.NEXT_PUBLIC_PUSHER_KEY;
  const cluster = process.env.PUSHER_CLUSTER || "ap2";

  if (!key) return null;

  return new PusherClient(key, { cluster });
};
