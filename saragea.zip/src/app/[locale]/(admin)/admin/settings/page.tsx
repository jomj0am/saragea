// app/[locale]/(admin)/admin/settings/page.tsx
import SettingsPageServer from './SettingsPageServer';

export default SettingsPageServer;
